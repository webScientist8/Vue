##Vue(拉取)

---


[TOC]

----

#VUE	

##数组的方法
- ES5 ES6
```
pop push shift unshift indexOf lastIndexOf reverse slice sort join map forEach filter for of  splice includes concat some every reduce find
```
includes 包含，返回的是boolean类型。includes和indexOf有区别，includes返回的是布尔值，indexOf返回的是索引值，如果没有找到返回-1，如果找到就返回查找值的起始位置索引值。另外，indexOf使用全等（===）进行判断，这会导致	对NaN的误判，而includes不会。在数组中includes、indexOf必须与与匹配项的值一致才行。
```
[NaN].indexOf(NaN)
// -1
[NaN].includes(NaN)
// true
['abc'].includes('a')
// false
['abc'].includes('abc')
// true
```

startsWith 参数字符串是否在原字符串的头部，返回boolean值
endsWith 参数字符串是否在原字符串的尾部，返回boolean值
some  只要有一项为true则为true，every 只要有一项为false则为false
find 找到回调函数返回true的那一项后就把那一项返回（只要找到后就不再往下验证），否则返回undefined
filter 把回调函数返回true的所有项返回，返回的是一个新数组 
map  把数组的每一项执行一个方法，此方法执行后返回的值组成一个新数组，并把这个新数组返回
reduce  返回叠加的结果
reduce的第二个参数是指定第一次prev的值
数组扁平化
每个callback后面都有一个参数，是this指向

bind方法只能绑定一次this，如果写了多次，以第一次为准

##框架和库
- 框架是库的升级版
- jquery zepto animate.css 库中提供了一些方法，我们主动调用库里的方法
- 框架是按照人家的写法，人家调用我们（被动），按照人家的用法使用

npm info vue查看vue版本
｛｛｝｝取值表达式	
vm.$set(vm.school,'address','huilongguan'); 新增属性
vm.\$data取data数据 ，vm.\$el取el数据 
##表单元素
- 只有表单元素才能双向绑定
- 指令  指令就是一个行间属性，而且必须以v-开头，一种是官方提供的，还有一种是自定义的



v-model 双向绑定
v-once 只绑定一次
v-html 识别数据中的html标签，展示成html
v-text 解决单行闪烁问题
｛｛｝｝可以做运算、三元表达式，但是不能写循环、函数等，｛｛｝｝是v-text的简写

要循环谁，就将v-for写在谁的身上
v-for="fruit in fruits"
v-for="(fruit,index) in fruits"
v-for="fruit of fruits"
v-for="(fruit,index) of fruits"
v-if="seen" 控制一个元素是否显示，只变化一次的建议使用这个
v-show 频繁切换显示隐藏的建议使用这个
v-cloak 防止闪烁，使用时先给其添加样式display:none

v-on:click="fn"'
v-on:click="fn($event)"  可以
v-on可以简写成@事件

methods存放的 是方法，不能和data中的内容重名，最后都会合并到vm的实例 上，被vm所代理，methods中this指向的都是vm实例，（不能使用箭头函数，因为会使this指向window）
@keydown.enter

v-if
v-else-if
v-else

bootstrap 中默认颜色 
default  灰色
warning  黄色
danger  红色
success  绿色
primary  蓝色
info  浅蓝色

vue-resourse它会将一个$http属性挂载vm上
then

Object.assign(target,obj1,obj2) es6方法，将后面对象的属性合并第一个对象上面，如果合并的属性有冲突，则以最后一次的那个属性性值为准
$.extend(target,obj1,obj2)
es7中...可以把一个对象展开

VUE中的事件修饰符
- 键盘修饰符
- .stop 阻止冒泡修饰符 e.stopPropagation || cancelBubble=true
- .prevent 阻止默认行为  e.preventDefault  returnValue=false
- .capture 捕获行为
- .self 事件源是自己时触发
- .once 绑定触发一次

：表示动态绑定，对应的值就是变量，如果要写字符串，就需要再加上' '，:height=“1“，里面的数字是Number类型
- v-bind 
- + :class
- + :style
:class="{bg:a.bg}"，如果是对象，则用{}，如果是数组用[ ]
v-bind:class='**'可以简写为:class='**'
- computed （和data是平级的）

**｛｛｝｝这里面的函数添加()，否则不会执行**
computed本身是一个对象，computed中值的是属性，但写的是方法 ，不支持异步
watch中的函数名要和要监控的数据必须同名
computed/method/watch

- h5
- e.dataTransfer.setDragImage( )
- draggable='true'
- dragstart
- dragover 想要触发drop事件，需要阻止dragover事件
- drop

###ref引用 
ref='img'  给dom元素起名，this.$refs.img  ，拿到真实dom元素

 e.dataTransfer.setDragImage(this.$refs.img[index],0,0)

created是在实例加载成功后执行
computed

解决异步的方案就是callback函数，setTimeout就是异步的
es6-promise可以做Promise的兼容问题
promise实例上有一个then方法
new Promice(function(resolve,reject){

})
resolve就是then中的第一个函数，reject就是then中的第二个函数

axios vue-resourece

directives指令

hash值会导致路径出现#
history不会出现#，但是刷新会导致404错误，上线时我们可以通过服务端来解决这种404问题
history.pushState('/home/home.html')
watch  deep:true  深度监控

beforeCreate
beforeMount
mounted 可以操作真实的DOM元素
beforeUpdate DOM更新前会触发这个事件，可以做一个全局的监控，一般用watch
updated
beforeDestroy  一般清除空定时器或者移除自定义函数
destoryed  移除所有的监听和数据 
VUE中的DOM渲染是异步的，vm.$nextTick等待渲染完成后获取真实DOM

static增加私有属性

```
$ npm install vue axios bootstrap
```
data中的数据都是用Object.defineProperty来定义，如果data中原本不存在某个属性，那么在对象上后加上的属性不会实现双向数据绑定，除非使用vm.$set(vm.b,'c',100)或者将新对象重新赋值给那个对象；
vm.\$set(vm.b,'c',100)；增加单个属性
Object.assign({},vm.obj,{c:200})；增加多个属性
vm.b={...vm.b,...{c:200}}；增加多个属性
{{}} 里面可以放三元运算符，赋值运算，不能写js语句
在双向绑定时，不能通过索引来改变数组的值，可以通过splice pop shift unshift 替换数组的方式来改变数组

语法糖 数据劫持 脏值检查 高阶 钩子函数 载荷
#### v-model 数据双向绑定
v-model 会忽略所有表单元素的 value、checked、selected
默认的v-model就是监控了Inpnut的input事件

v-model给checkbox绑定一个值，默认是布尔类型，如果checkbox绑定n个值，此时数据必须是数组类型，并且checkbox必须有value属性，当选中后会将value属性放到这个数组中
对radio类型的input标签使用v-model时，也必须有value值，点击单选标签时，会自动将点击后的结果赋予给v-model绑定的数据。如果v-model绑定的数据的值和value值相同则选中。

vue中的el不能用body和html，只能使用普通的节点，el使用的方法是querySelector
option禁用选择 disabled

mvvm  model数据 view视图 viewmodel视图数据

####v-bind 动态绑定
在给元素的属性动态绑定数据时，需要使用v-bind指令。
v-bind:title="msg"可以简写为:title="msg"
####methods
methods中的方法，名字不能和data中的属性名相同因为这里会和data合并后一起挂载在实例上。
methods中的方法，里面的this指向vm实例
####v-on
绑定事件需要使用v-on
v-on:click="say"可以简写为@click="say	"
keydown.enter
keydown.ctrl.enter
keydown.ctrl.67
自定义键盘修饰符
Vue.config.keyCodes.abc=13
keydown.abc

v-once 只绑定一次
v-text v-cloak 解决闪烁问题
v-html 识别字符串中的html标签
v-for 循环，循环谁就放在谁身上，可以采用括号的方式（value,key,index）in obj   /   (value,index) in ary

####computed
计算属性，看起来是一个方法，实质是属性，由两部分组成，分别是get和set，默认是get

v-if，v-else,v-else-if，操作的dom元素，如果切换的元素相同要使用：key，否则vue会觉得没发生变化所以不会更改。
v-if 和v-else对应的元素必须相邻。：key只针对v-if和v-else使用。
```
    <template   v-if="flag" >
        <label >用户名</label>
        <input type="text" :key="1">
    </template>
    <template v-else >
        <label >密码</label>
        <input type="text" :key="2">
    </template>
    <button @click="flag=!flag">aa</button>
```
v-show操作的样式（频繁操作显示/隐藏时使用）

#### ref
mounted(){}  VUE提供的一个回调函数，钩子函数，获取真实的dom
ref不能重名，如果重名则vm.$refs.[ref名称]默认输出最后一个，但是如果ref和v-for一起使用，则获取的是一个数组
vm.$nextTick( fn )下一队列，会等待dom完成渲染后执行此回调函数

vm.$data vm.$el vm.$nextTick vm.$refs vm.watch

watch和computed 
computed不能实现异步，watch可以实现异步操作，有的时候，watch和computed可以相互转化
watch中的a( newValue,oldValue){} 有两个参数
####VUE生命周期
`beforeCreate `准备方法，生命周期，此时数据没有挂载，一般不用
`created `   ajax获取数据，ajax是异步的，不会等待返回结果
`beforeMount`  挂载之前，template只能存在一个根节点
`mounted  `挂载，可以获取真实的dom元素，一般情况下我们会在mounted中添加$nextTick
`beforeUpdate`  页面发生更改都会触发此函数
`updated`  watch比此方法好用
`beforeDestroy` 销毁前，一般不会手动销毁，组件切换时会触发销毁，可以清除定时器，解绑函数
`destroyed`

![Alt text](./1507794020306.png)


filters中的this是window

过滤器只能在{{}}和v-text中使用

####打包工具
#####模块化（多人开发，命名冲突）
- 单例（不能完全解决命名冲突）调用时名字过长
- 闭包：函数执行时就会产生一个作用域，此时可以称之为闭包，完整的闭包就是当一个函数执行时返回一个引用数据类型，并用结果被外部变量接收，此时这个函数不会销毁。ES6中{let a=1} 大括号也有块级作用域的。
- requirejs（AMD） seajs（CMD）前端解决模块化的库
- COMMONJS规范 node提供的  require  module.exports
- ES6 import和export，有兼容性问题
- webpack

引入js文件时，在type中写上module，表明这个是模块文件
```
<script src="js/main.js" type="module"></script>
```

```
export let str='hello';//逐个导出，会将这个放到一个对象中，这种方法不能直接将匿名函数导出
{str:'hello'}
export default {
	name:'l'
}//默认导出，直接将其导出，不会把它放在一个对象中，这种方法可以不写函数名并将其导出，导出的函数名为default

import {str} from './xx.js'// 逐个导出
import * as obj from './xx.js' //导出为一个对象，使用`* as`
```
导出为一个对象，使用`* as`
```
let {name,a:b}={name:'l',a:1}// 把a的值赋给b
```

#### webpack
- webpack基于node，语法遵循commonjs
- CSS预编译器
- 图片base64，较小图片自动转化base64
- 每次引用一个文件都会产生http请求，webpack可以进行打包
- es6转es5
- 更改代码浏览器自动刷新（webpack-dev-server）
- webpack可以帮我们提供服务接口（如localhost）
- 支持模块化，可以转化commonjs，可以转化es6，可以转化amd cmd umd
webpack一般不会采用全局安装，全局安装会造成版本差异
#####使用webpack
- 使用webpack，运行的就是bin下的webpack.js，默认会找当前目录下叫webpack.config.js的文件
- 配置scripts脚本，在当前目录下

```
npm run start可以简写成npm start 
npm run dev
```
转义es6，需要以下依赖  
```
//babel-core 是babel的核心模块，babel-loader用来执行转义
$ npm install babel-core babel-loader --save-dev
//预设语言
$ npm install babel-preset-es2015 --save-dev
//配置.babel
{
  "presets":["es2015"]
}
```
```
module.exports = {
    //入口文件，会将入口中所有依赖的结果打包到出口中
    entry: './src/main.js',
    output: {
        //打包后的文件名字
        filename: 'build.js',
        //打包后文件存放的绝对路径
        path: __dirname + '/dist'//还有一种方式是引入path模块，使用path.resolve('/dist')就可以转换为绝对路径
    },
    //解释ES6语法，需要提供对应模块的规则
    module: {
        /* 设置ES转义对应的规则
        *  js用babel-loader进行翻译
        *  node_modules不用解析
        */
        rules: [
            {test: /\.js$/, use: 'babel-loader', exclude: /node_modules/},
            /*style-loader将转化好的css插入到style标签内，css-loader用来解析css模块的*/
            /*从右往左写，顺序不能反*/
            {test:/\.css$/,use:['style-loader','css-loader']},
            //编译less文件，用到的loader按顺序从右往左写
            {test:/\.less$/,use:['style-loader','css-loader','less-loader']}
           //解析图片,limit限制图片大小
           {test:/\.(jpg|png|gif|svg)$/,use:['url-loader?limit=8']}
        ]
    }
};
```

babel-preset-stage-0

安装less  
npm install less less-loader --save-dev
npm install file-loader url-loader --save-dev

不能在js中直接使用图片地址，否则会导致404，webpack不识别，需要使用import
```
export let str='This is aaaaa';
let oImg=document.createElement('img');
import jpg from './contentArea-topAD1.jpg';
oImg.src=jpg;
document.body.appendChild(oImg);
```

打包html，正常情况下应该在src创建html，最终将打包的文件引入，导出到dist目录下
```
npm install html-webpack-plugin --save-dev
```
webpack-dev-server 
- 创建本地服务运行项目
- 支持热更新（代码发动页面刷新）

```
npm install webpack-dev-server --save-dev
```

